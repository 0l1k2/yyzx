package com.cy.mapper;

import com.cy.domain.Nurselevelitem;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface NurselevelitemMapper extends BaseMapper<Nurselevelitem> {

}
