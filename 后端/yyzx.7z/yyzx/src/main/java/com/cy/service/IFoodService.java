package com.cy.service;

import com.cy.domain.Food;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author div F
 * @since 2025-06-25
 */
public interface IFoodService extends IService<Food> {

}
