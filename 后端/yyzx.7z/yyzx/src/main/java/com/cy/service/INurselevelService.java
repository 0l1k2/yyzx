package com.cy.service;

import com.cy.domain.Nurselevel;
import com.baomidou.mybatisplus.extension.service.IService;


public interface INurselevelService extends IService<Nurselevel> {

}
