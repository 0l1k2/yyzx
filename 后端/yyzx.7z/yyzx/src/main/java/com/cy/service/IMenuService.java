package com.cy.service;

import com.cy.domain.Menu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author div F
 * @since 2025-06-23
 */
public interface IMenuService extends IService<Menu> {

}
