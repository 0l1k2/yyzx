package com.cy.mapper;

import com.cy.domain.Nurselevel;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;



public interface NurselevelMapper extends BaseMapper<Nurselevel> {

}
