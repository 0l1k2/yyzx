package com.cy.service;

import com.cy.domain.Nurselevelitem;
import com.baomidou.mybatisplus.extension.service.IService;


public interface INurselevelitemService extends IService<Nurselevelitem> {

}
