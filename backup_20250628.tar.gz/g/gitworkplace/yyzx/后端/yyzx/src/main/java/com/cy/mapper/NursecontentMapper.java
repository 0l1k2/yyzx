package com.cy.mapper;

import com.cy.domain.Nursecontent;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface NursecontentMapper extends BaseMapper<Nursecontent> {

}
