package com.cy.service;

import com.cy.domain.Bed;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author div F
 * @since 2025-06-24
 */
public interface IBedService extends IService<Bed> {

}
