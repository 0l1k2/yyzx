package com.cy.service.impl;

import com.cy.domain.Nurselevelitem;
import com.cy.mapper.NurselevelitemMapper;
import com.cy.service.INurselevelitemService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;


@Service
public class NurselevelitemServiceImpl extends ServiceImpl<NurselevelitemMapper, Nurselevelitem> implements INurselevelitemService {

}
